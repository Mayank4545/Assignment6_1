
public class RunnableClass implements Runnable{

	@Override
	public void run() {
		
		int i = 10;
		int j = 1;
		System.out.println("Timer Started");

		do{
			System.out.println(i);
			try {
				Thread.sleep(1000); /*sleep for 1 microseconds */
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (i == 1) {
				i = 10;
				System.out.println("Session timeout");
				System.out.println("New session started");
			}else{
				j = i + 1;	/*mismatch the "j" value from "i" so that it will become never ending timer */
				i--;
			}
		}while(i != j ); /* Infinite loop*/
	
		
	}

}
