
public class Timer {
	
	public static void main(String[] args) {
		
		RunnableClass runnable = new RunnableClass(); /*call runnable interface*/
		Thread t2 = new Thread(runnable);
		t2.start(); /*Thread started for runnable*/
		
	}
}